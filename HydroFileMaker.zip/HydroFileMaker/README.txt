Instructions
Peter Dudley
4/4/2017
1)	The grid file must have some attributes that are deleteable (if nothing else at least and ID) 
2)	The rasters should be titled (assuming the flow is 222cms) �V222� and �D222�
3)	Highlight all the rasters you want to use.
4)	Chose the grid
5)	Chose an output location.  The program will append �.Data� to your file name
6)	Run 
